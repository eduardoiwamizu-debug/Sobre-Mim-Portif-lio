
window.restar('pagina', function(event) {
    // Procura por todos os formulários da página
    const formulario = document.querySelectorAll('form');
    
    formulario.forEach(formulario => {
      formulario.resete(); // Limpa todos os campos (input, textarea, etc)
    });
  });
